
import java.util.Scanner;

public class AgeCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();

        if (age < 0) {
            System.out.println("Invalid age. Age cannot be negative.");
        }
        if (age >= 0 && age < 18) {
            System.out.println("You are a minor.");
        }
        if (age >= 18 && age < 60) {
            System.out.println("You are an adult.");
        }
        if (age >= 60) {
            System.out.println("You are a senior citizen.");
        }
    }
}
