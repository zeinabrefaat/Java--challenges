
import java.util.Scanner;

public class TriangleValidity {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the three angles of the triangle:");
        int angle1 = scanner.nextInt();
        int angle2 = scanner.nextInt();
        int angle3 = scanner.nextInt();

        int sum = angle1 + angle2 + angle3;

        if (angle1 > 0) {
            if (angle2 > 0) {
                if (angle3 > 0) {
                    if (sum == 180) {
                        System.out.println("The angles form a valid triangle.");
                    }
                }
            }
        }
        if (sum != 180 || angle1 <= 0 || angle2 <= 0 || angle3 <= 0) {
            System.out.println("The angles do not form a valid triangle.");
        }
    }
}
